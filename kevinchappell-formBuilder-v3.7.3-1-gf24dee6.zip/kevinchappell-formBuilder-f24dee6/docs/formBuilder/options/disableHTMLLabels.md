# disableHTMLLabels
Disables HTML labels.

## Usage
```javascript
var options = {
  disableHTMLLabels: true
};
$(container).formBuilder(options);
```
<p data-height="525" data-embed-version="2" data-theme-id="22927" data-slug-hash="yRJPNb" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
